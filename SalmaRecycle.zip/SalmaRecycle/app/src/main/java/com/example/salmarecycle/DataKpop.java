package com.example.salmarecycle;

import java.util.ArrayList;

public class DataKpop {
    private static String[] namakpop = {
            "2PM",
            "Blackpink",
            "BTS",
            "EXO",
            "G-Dragon",
            "Gfriend",
            "Red Velvet",
            "SNSD",
            "Super Junior",
            "Twice"
    };

    private static String [] deskpop= {
            "BOY",
            "GIRL",
            "BOY",
            "BOY",
            "BOY",
            "GIRL",
            "GIRL",
            "GIRL",
            "BOY",
            "GIRL"
    };

    private static int [] logokpop = {
            R.drawable.pm,
            R.drawable.blackpink,
            R.drawable.bts,
            R.drawable.exo,
            R.drawable.gdragon,
            R.drawable.gfriend,
            R.drawable.redvelvet,
            R.drawable.snsd,
            R.drawable.suju,
            R.drawable.twice
    };

    static ArrayList<Kpop> getListData(){
        ArrayList<Kpop> list = new ArrayList<>();
        for (int position = 0; position <namakpop.length; position++){
            Kpop kpop = new Kpop();
            kpop.setNamakpop(namakpop[position]);
            kpop.setDeskpop(deskpop[position]);
            kpop.setLogo(logokpop[position]);
            list.add(kpop);
        }
        return list;
    }
};
