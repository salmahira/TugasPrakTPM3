package com.example.salmarecycle;

public class Kpop {

    private String namakpop;
    private String deskpop;
    private int logo;

    public String getNamakpop() {
        return namakpop;
    }

    public void setNamakpop(String namaklub) { this.namakpop = namaklub;
    }

    public String getDeskpop() {
        return deskpop;
    }

    public void setDeskpop(String desklub) {
        this.deskpop = desklub;
    }

    public int getLogo() {
        return logo;
    }

    public void setLogo(int logo) {
        this.logo = logo;
    }
}
