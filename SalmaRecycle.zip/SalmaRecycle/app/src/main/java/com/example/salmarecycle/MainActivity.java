package com.example.salmarecycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv_kpop;
    private ArrayList<Kpop> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rv_kpop = findViewById(R.id.rv_kpop);
        rv_kpop.setHasFixedSize(true);

        list.addAll(DataKpop.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rv_kpop.setLayoutManager(new LinearLayoutManager(this));
        KpopAdapter klubAdapter = new KpopAdapter(list);
        rv_kpop.setAdapter(klubAdapter);
    }
}